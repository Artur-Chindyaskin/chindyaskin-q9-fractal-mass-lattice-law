FINAL INSERT PACKAGE v3 CHECKED — INSERTION MAP

Delete every broken markdown table currently inside the article.
Insert the PNG files listed below. Do not insert CSV files into Substack.
CSV files are included only as backup/audit material.

Section 7: tables_to_insert/table_15_status_legend.png

Section 13: delete the broken primary mass table. Insert tables_to_insert/table_01_primary_mass_coordinate.png. Then keep the mean N residual text. Then insert figures_to_insert/SECTION_13_fig_01_primary_n_axis.png.

Section 14: delete the broken ratio table. Insert tables_to_insert/table_02_observed_18_step.png.

Section 15: delete the broken empirical branch table. Insert tables_to_insert/table_03_empirical_j_branch_fit.png.

Section 16: delete the fixed-mode error table. Do not insert a new table here. Fixed errors are already in table_01_primary_mass_coordinate.png.

Section 17: delete the calibrated-error table. Do not insert a new table here. Calibrated errors are already in table_01_primary_mass_coordinate.png.

Section 20: delete the upper-node markdown table. Insert tables_to_insert/table_04_upper_nodes.png.

Section 21: after the Saturn-Sun bridge error statement, insert tables_to_insert/table_05_saturn_sun_bridge.png.

Section 29: delete the metrics markdown table. Use a plain text metric list only. No PNG table needed.

Section 31: after N_Alpha(k) = 46k - 511.766115, insert figures_to_insert/SECTION_31_fig_04_alpha_bridge.png. Then insert tables_to_insert/table_06_alpha_ladder.png.

Section 32: delete the micro-world markdown table. Insert tables_to_insert/table_07_particle_anchor_overlay.png.

Section 33: delete the collider markdown table. After the corridor-boundary formulas, insert figures_to_insert/SECTION_33_fig_02_collider_corridors.png. Then insert tables_to_insert/table_08_collider_corridors_full.png.

Section 33 known-anchor overlay: after the text about LHC/FCC locks, insert tables_to_insert/table_09_known_energy_anchor_overlay.png.

Section 34: delete the clean collider corridor markdown table. Insert tables_to_insert/table_10_clean_collider_search_corridors.png.

Section 35: delete the macro anchor markdown table. After the opening macro-corridor explanation, insert figures_to_insert/SECTION_35_fig_03_macro_mass_ladder.png. Then insert tables_to_insert/table_11_macro_anchor_overlay.png.

Section 35 macro corridor ledger: delete the large macro corridor markdown table. Insert exactly these 3 tables: tables_to_insert/table_12_macro_corridor_ledger_part_1.png, tables_to_insert/table_12_macro_corridor_ledger_part_2.png, tables_to_insert/table_12_macro_corridor_ledger_part_3.png.

Section 36: delete the clean macro markdown table. Insert tables_to_insert/table_13_clean_macro_search_corridors.png.

End: add link to this ZIP as the calculation/publication package.
