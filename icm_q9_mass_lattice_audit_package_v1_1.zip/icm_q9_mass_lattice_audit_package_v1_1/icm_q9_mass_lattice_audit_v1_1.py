#!/usr/bin/env python3
# ICM Q9 Planetary-Stellar Mass-Lattice Audit v1.1
# Reproducibility script. See README_calculation_protocol.md for source register and method notes.

import math
import numpy as np
import pandas as pd

Q9 = 63243.80
mp = 1.67262192595e-27

bodies = [
    ("Mercury", 330_104_000_000_000_000_000_000, -24),
    ("Mars",    641_693_000_000_000_000_000_000, -21),
    ("Venus",   4_867_320_000_000_000_000_000_000, -13),
    ("Earth",   5_972_190_000_000_000_000_000_000, -12),
    ("Uranus",  86_810_300_000_000_000_000_000_000, -1),
    ("Neptune", 102_410_000_000_000_000_000_000_000, 0),
    ("Saturn",  568_319_000_000_000_000_000_000_000, 7),
    ("Jupiter", 1_898_130_000_000_000_000_000_000_000, 12),
    ("Sun",     1_989_100 * 1e24, 41),
]

def lattice_mass(N):
    return mp * Q9 ** (11 + N/46)

def N_calc(mass):
    return 46 * (math.log(mass/mp, Q9) - 11)

rows = []
for body, mass, N in bodies:
    pred = lattice_mass(N)
    rows.append({
        "body": body,
        "measured_mass_kg": mass,
        "N_calc": N_calc(mass),
        "assigned_N": N,
        "predicted_mass_kg": pred,
        "error_pct": (pred/mass - 1)*100,
    })
df = pd.DataFrame(rows)
print(df)
print("MAE:", df["error_pct"].abs().mean())
print("q = Q9^(6/23):", Q9**(6/23))
print("N=24 in Jupiter masses:", lattice_mass(24) / df.loc[df.body == "Jupiter", "measured_mass_kg"].iloc[0])
