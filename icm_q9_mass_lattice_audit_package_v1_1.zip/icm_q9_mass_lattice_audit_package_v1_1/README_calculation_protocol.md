# ICM Q₉ Planetary–Stellar Mass-Lattice Audit Package v1.1

This package supports the working draft **Chindyaskin Q₉ Planetary–Stellar Mass-Lattice Law**.

## Core formula

`M_N = m_p × Q₉^(11 + N/46)`

## Data sources

- Proton mass: NIST CODATA value, `m_p = 1.67262192595e-27 kg`.
- Planetary masses: NASA Planet Compare mass values.
- Solar mass: NASA Sun Fact Sheet mass value, `1,989,100 × 10^24 kg`.

## Body-selection rule

Included in the primary proof layer:

- Mercury, Venus, Earth, Mars, Uranus, Neptune, Saturn, Jupiter, Sun.
- The ~18 Jupiter-mass node is included as a predicted/reference upper node.

Excluded from the primary proof layer:

- moons, rings, dust, debris, asteroids, dwarf bodies.

These excluded objects belong to the secondary relay/fractionation layer.

## Main v1.1 metrics

- `q = Q₉^(6/23) = 17.882962544937`
- `r = Q₉^(1/46) = 1.271656910227`
- `M0 = m_p × Q₉^11 = 1.082917340846e+26 kg`
- Fixed proton-Q₉ MAE: `3.371099%`
- Calibrated-seed MAE: `2.286688%`
- Effective denominator D, all bodies: `45.994583`
- Mean absolute N-residual: `0.137436`
- Empirical J-branch q: `17.837066232313`
- N=24 upper node: `18.245186 Jupiter masses`
- Saturn→Sun bridge error using empirical q_J: `0.311778%`
- Best denominator-scan D: `46.050000`
- Random-control trials: `500000`
- Random sets as good or better under the strict control: `0.000000%`

## Tables

1. `table1_fixed_proton_q9_primary_lattice.csv`
2. `table2_observed_approx_18_step_ratios.csv`
3. `table3_empirical_j_branch.csv`
4. `table4_calibrated_seed_q9_step.csv`
5. `table5_upper_nodes.csv`
6. `table6_denominator_46_regression_leave_one_out.csv`
7. `table7_denominator_scan_35_to_60.csv`
8. `table8_q9_sensitivity.csv`
9. `table9_saturn_sun_bridge.csv`
10. `table10_random_control_summary.csv`
11. `table11_inclusion_exclusion_rules.csv`

## v1.1 additions over v1.0

- leave-one-out denominator test;
- alternative denominator scan from D=35 to D=60;
- Q₉ sensitivity table;
- stricter random-control summary with 500,000 trials;
- cleaner source/method protocol.

## Publication note

The approximate mass coefficient near 18 is phrased neutrally as an observed mass step.
No personal or historical attribution is included in the package.
